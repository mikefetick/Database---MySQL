<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Strict//EN"
"http://www.w3.org/TR/xhtml1/DTD/xhtml1-strict.dtd">
<!--
   COLEMAN UNIVERSITY
   COM230 SQL AND DATABASE DESIGN
   Project 4
   Famous Quotes CMS; Managing Authors 

   Author: Michael Fetick, 84270
   Date:   22 September 2013

   Location/Filename: editcat.php
   Supporting Files: (none)
-->
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<title>Quote CMS: Edit Category</title>
<meta http-equiv="content-type"
    content="text/html; charset=iso-8859-1" />
</head>
<body>
<?php

$dbcnx = @mysql_connect('localhost', 'pm84270', 'c4891a25');
if (!$dbcnx) 
{
  exit('<p>Unable to connect to the ' .
      'database server at this time.</p>');
}

if (!@mysql_select_db('pm84270')) 
{
  exit('<p>Unable to locate the ' .
      'database at this time.</p>');
}

if (isset($_POST['cname'])):
  // The category's details have
  // been updated.

  $cname = $_POST['cname'];
  $cid = $_POST['cid'];
  
  $sql = "UPDATE fq_category SET
          name='$cname'
          WHERE category_id ='$cid'";
  if (@mysql_query($sql)) 
  {
    echo '<p>Category details updated.</p>';
  } 
  else 
  {
    echo '<p>Error updating category details: ' .
        mysql_error() . '</p>';
  }

?>

<p><a href="categories.php">Return to category list</a></p>

<?php else: // Allow the user to edit the category

  $cid = $_GET['cid'];
    
  $cats = @mysql_query("SELECT name FROM fq_category WHERE category_id = '$cid'");
  
    
  if (!$cats) {
    exit('<p>Error fetching category details: ' .
        mysql_error() . '</p>');
  }

  $cat = mysql_fetch_array($cats);

  $cname = $cat["name"];

  // Convert special characters for safe use
  // as an HTML attribute.
  $cname = htmlspecialchars($cname);

?>

<form action="<?php echo $_SERVER['PHP_SELF']; ?>" method="post">
<p>Edit the category:</p>
<label>Name: <input type="text" name="cname" value="<?php echo $cname; ?>" /></label><br />
<input type="hidden" name="cid" value="<?php echo $cid; ?>" />
<input type="submit" value="SUBMIT" /></p>
</form>

<?php endif; ?>

</body>
</html>
