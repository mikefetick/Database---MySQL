<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Strict//EN"
"http://www.w3.org/TR/xhtml1/DTD/xhtml1-strict.dtd">
<!--
   COLEMAN UNIVERSITY
   COM230 SQL AND DATABASE DESIGN
   Project 4
   Famous Quotes CMS; Managing Authors 

   Author: Michael Fetick, 84270
   Date:   22 September 2013

   Location/Filename: authors.php
   Supporting Files: (none)
-->
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<title>Quote CMS: Manage Authors</title>
<meta http-equiv="content-type"
    content="text/html; charset=iso-8859-1" />
</head>
<body>
<h1>Manage Authors</h1>
<ul>
<?php

$dbcnx = @mysql_connect('localhost', 'pm84270', 'c4891a25');
if (!$dbcnx) 
{
  exit('<p>Unable to connect to the ' .
      'database server at this time.</p>');
}

if (!@mysql_select_db('pm84270')) 
{
  exit('<p>Unable to locate the ' .
      'database at this time.</p>');
}

$authors = @mysql_query('SELECT author_id, name FROM fq_author');
if (!$authors) 
{
  exit('<p>Error retrieving authors from database!<br />'.
      'Error: ' . mysql_error() . '</p>');
}

while ($author = mysql_fetch_array($authors)) 
{
  $aid = $author['author_id'];
  $aname = htmlspecialchars($author['name']);
  echo "<li>$aname ".
      "<a href='editauthor.php?aid=$aid'>Edit</a> ".
      "<a href='deleteauthor.php?aid=$aid'>Delete</a></li>";
}

?>
</ul>
<p><a href="newauthor.php">Add new author</a></p>
<p><a href="index.html">Return to front page</a></p>
</body>
</html>
