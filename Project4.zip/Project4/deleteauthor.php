<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Strict//EN"
"http://www.w3.org/TR/xhtml1/DTD/xhtml1-strict.dtd">
<!--
   COLEMAN UNIVERSITY
   COM230 SQL AND DATABASE DESIGN
   Project 4
   Famous Quotes CMS; Managing Authors 

   Author: Michael Fetick, 84270
   Date:   23 September 2013

   Location/Filename: deleteauthor.php
   Supporting Files: (none)
-->
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<title>Quote CMS: Delete Author</title>
<meta http-equiv="content-type"
    content="text/html; charset=iso-8859-1" />
</head>
<body>
<h1>Delete Author</h1>
<?php
$dbcnx = @mysql_connect('localhost', 'pm84270', 'c4891a25');

if (!$dbcnx) 
{
exit('<p>Unable to connect to the ' .
'database server at this time.</p>');
}
if (!@mysql_select_db('pm84270')) 
exit('<p>Unable to locate the  ' .
'database at this time.</p>');
}

// Delete all quotes belonging to the author
// along with the entry for the author.
$aid = $_GET['aid'];

$ok1 = @mysql_query(
"DELETE fq_quotes, fq_quotecategory
FROM fq_quotes, fq_quotecategory
WHERE fq_quotes.quote_id=fq_quotecategory.quote_id AND author_id='$aid'");

$ok2 = @mysql_query("DELETE FROM fq_quotes WHERE author_id='$aid'");

$ok3 = @mysql_query("DELETE FROM fq_author WHERE author_id='$aid'");

if ($ok1 and $ok2 and $ok3) 
{
echo '<p>Author deleted successfully!</p>';
} 
else 
{
echo '<p>Error deleting author from database!<br />'.
'Error: ' . mysql_error() . '</p>';
}
?>
<p><a href="authors.php">Return to authors list</a></p>
</body>
</html>
