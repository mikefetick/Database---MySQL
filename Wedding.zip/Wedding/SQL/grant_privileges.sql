GRANT SELECT, INSERT, DELETE, UPDATE
    ON wedding.*
    TO fred@localhost
    IDENTIFIED by 'shhh';
