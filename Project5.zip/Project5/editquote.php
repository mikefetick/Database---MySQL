<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Strict//EN"
"http://www.w3.org/TR/xhtml1/DTD/xhtml1-strict.dtd">
<!--
   COLEMAN UNIVERSITY
   COM230 SQL AND DATABASE DESIGN
   Project 4
   Famous Quotes CMS; Managing Authors 

   Author: Michael Fetick, 84270
   Date:   22 September 2013

   Location/Filename: editquote.php
   Supporting Files: (none)
-->
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<title>Quote CMS: Edit Quote</title>
<meta http-equiv="content-type"
    content="text/html; charset=iso-8859-1" />
</head>
<body>
<?php

$dbcnx = @mysql_connect('localhost', 'pm84270', 'c4891a25');
if (!$dbcnx) 
{
  exit('<p>Unable to connect to the ' .
      'database server at this time.</p>');
}

if (!@mysql_select_db('pm84270')) 
{
  exit('<p>Unable to locate the ' .
      'database at this time.</p>');
}

if (isset($_POST['quotetext'])):
  // The quote's details have
  // been updated.
  
  $qid = $_POST['qid'];
  $aid = $_POST['aid'];
  $quotetext = $_POST['quotetext'];

  $sql = "UPDATE fq_quotes SET
          quotetext='$quotetext',
          author_id='$aid'
          WHERE quote_id='$qid'";
  if (mysql_query($sql)) 
  {
    echo '<p>Quote details updated.</p>';
  } 
  else 
  {
    exit('<p>Error updating quote details: ' .
        mysql_error() . '</p>');
  }

  // Delete all existing entries for this
  // quote from the quotecategory table
  $ok = mysql_query("DELETE FROM fq_quotecategory
                     WHERE quote_id = '$qid'");
  if (!$ok) 
  {
    exit('<p>Error removing quote from all categories:' .
        mysql_error() . '</p>');
  }

  if (isset($_POST['cats'])) 
  {
    $cats = $_POST['cats'];
  } 
  else 
  {
    $cats = array();
  }

  foreach ($cats as $catID) 
  {
    $sql = "INSERT IGNORE INTO fq_quotecategory
            SET quote_id = '$qid', category_id = '$catID'";
    $ok = @mysql_query($sql);
    if (!$ok) 
    {
      echo "<p>Error inserting quote into category $catID: " .
          mysql_error() . '</p>';
    }
  }

?>

<p><a href="quotes.php">New quote search</a></p>

<?php else: // Allow the user to edit the quote

  $qid = $_GET['qid'];

  $quote = @mysql_query(
    "SELECT quotetext, author_id FROM fq_quotes WHERE quote_id =
    '$qid'");
  if (!$quote) 
  {
    exit('<p>Error fetching quote details: ' .
        mysql_error() . '</p>');
  }

  $quote = mysql_fetch_array($quote);

  $quotetext = $quote['quotetext'];
  $authid = $quote['author_id'];

  // Convert HTML special characters
  // in database value for use in
  // an HTML document.
  $quotetext = htmlspecialchars($quotetext);

  // Get lists of authors and categories for
  // the select box and checkboxes.
  $authors = @mysql_query('SELECT author_id, name FROM fq_author');
  if (!$authors) 
  {
    exit('<p>Unable to obtain author list from the database.</p>');
  }

  $cats = @mysql_query('SELECT category_id, name FROM 
    fq_category');
  if (!$cats) 
  {
    exit('<p>Unable to obtain category list from the 
     database.</p>');
  }
?>

<form action="<?php echo $_SERVER['PHP_SELF']; ?>" method="post">
<p>Edit the quote:<br />
<textarea name="quotetext" rows="5" cols="45">
<?php echo $quotetext; ?></textarea>
<p>Author:
<select name="aid" size="1">
<?php
  while ($author = mysql_fetch_array($authors)) 
  {
    $aid = $author['author_id'];
    $aname = htmlspecialchars($author['name']);
    if ($aid == $authid) 
    {
      echo "<option selected='selected'
    value='$aid'>$aname</option>\n";
   } 
   else 
   {
      echo "<option value='$aid'>$aname</option>\n";
   }
  }
?>
</select></p>
<p>In categories:<br />
<?php
  while ($cat = mysql_fetch_array($cats)) 
  {
    $cid = $cat['category_id'];
    $cname = htmlspecialchars($cat['name']);

    // Check if the quote is in this category
    $result = @mysql_query(
      "SELECT * FROM fq_quotecategory
       WHERE quote_id = '$qid' AND category_id = '$cid'");
    if (!$result) 
    {
      exit('<p>Error fetching quote details: ' .
          mysql_error() . '</p>');
    }

    // mysql_num_rows gives the number of entries
    // in a result set. In this case, if the result
    // contains one or more rows, the condition
    // below will evaluate to true to indicate that
    // the quote does belong to the category, and the
    // checkbox should be checked.
    if (mysql_num_rows($result)) 
    {
      echo "<input type='checkbox' checked='checked'
      name='cats[]' value='$cid' />$cname<br />\n";
    } 
	else 
    {
      echo "<input type='checkbox' name='cats[]' value='$cid' 
      />$cname<br />\n";
    }
  }
?>
</p>
<input type="hidden" name="qid" value="<?php echo $qid; ?>" />
<input type="submit" value="SUBMIT" />
</form>

<?php endif; ?>
</body>
</html>

