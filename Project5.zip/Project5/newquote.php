<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Strict//EN"
"http://www.w3.org/TR/xhtml1/DTD/xhtml1-strict.dtd">
<!--
   COLEMAN UNIVERSITY
   COM230 SQL AND DATABASE DESIGN
   Project 4
   Famous Quotes CMS; Managing Authors 

   Author: Michael Fetick, 84270
   Date:   22 September 2013

   Location/Filename: newquote.php
   Supporting Files: (none)
-->
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<title>Quote CMS: Add New Quote</title>
<meta http-equiv="content-type"
    content="text/html; charset=iso-8859-1" />
</head>
<body>
<?php

$dbcnx = @mysql_connect('localhost', 'pm84270', 'c4891a25');
if (!$dbcnx) 
{
  exit('<p>Unable to connect to the ' .
      'database server at this time.</p>');
}

if (!@mysql_select_db('pm84270')) 
{
  exit('<p>Unable to locate the ' .
      'database at this time.</p>');
}

if (isset($_POST['quotetext'])): 
  // A new quote has been entered
  // using the form.

  $aid = $_POST['aid'];
  $quotetext = $_POST['quotetext'];
  $cats = $_POST['cats'];

  if ($aid == '') 
  {
    exit('<p>You must choose an author for this quote. Click 
       "Back" and try again.</p>');
  }

  $sql = "INSERT INTO fq_quotes SET
      quotetext='$quotetext',
      quotedate=CURDATE(),
      author_id='$aid'";
  if (@mysql_query($sql)) 
  {
    echo '<p>New Quote added</p>';
  } 
  else 
  {
    exit('<p>Error adding new quote: ' . mysql_error() . '</p>');
  }

  $qid = mysql_insert_id();

  if (isset($_POST['cats'])) 
  {
    $cats = $_POST['cats'];
  } 
  else 
  {
    $cats = array();
  }

  $numCats = 0;
  foreach ($cats as $catID) 
  {
    $sql = "INSERT IGNORE INTO fq_quotecategory
            SET quote_id = $qid, category_id = $catID";
    $ok = @mysql_query($sql);
    if ($ok) 
    {
      $numCats = $numCats + 1;
    } 
    else 
    {
      echo "<p>Error inserting quote into category $catID: " .
          mysql_error() . '</p>';
    }
  }
?>

<p>Quote was added to <?php echo $numCats; ?> categories.</p>

<p><a href="<?php echo $_SERVER['PHP_SELF']; ?>">Add another quote</a></p>
<p><a href="quotes.php">Return to quote search</a></p>

<?php
else: // Allow the user to enter a new quote

  $authors = @mysql_query('SELECT author_id, name FROM  
  fq_author');
  if (!$authors) 
  {
    exit('<p>Unable to obtain author list from the 
    database.</p>');
  }

  $cats = @mysql_query('SELECT category_id, name FROM 
  fq_category');
  if (!$cats) 
  {
    exit('<p>Unable to obtain category list from the 
    database.</p>');
  }
?>

<form action="<?php echo $_SERVER['PHP_SELF']; ?>" method="post">
<p>Enter the new quote:<br />
<textarea name="quotetext" rows="5" cols="45">
</textarea></p>
<p>Author:
<select name="aid" size="1">
  <option selected value="">Select One</option>
  <option value="">---------</option>
<?php
  while ($author = mysql_fetch_array($authors)) 
  {
    $aid = $author['author_id'];
    $aname = htmlspecialchars($author['name']);
    echo "<option value='$aid'>$aname</option>\n";
  }
?>
</select></p>
<p>Place in categories:<br />
<?php
  while ($cat = mysql_fetch_array($cats)) 
  {
    $cid = $cat['category_id'];
    $cname = htmlspecialchars($cat['name']);
    echo "<label><input type='checkbox' name='cats[]' 
    value='$cid' />$cname</label><br />\n";
  }
?>
</p>
<input type="submit" value="SUBMIT" />
</form>
<?php endif; ?>
</body>
</html>

