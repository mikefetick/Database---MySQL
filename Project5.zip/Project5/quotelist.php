<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Strict//EN"
"http://www.w3.org/TR/xhtml1/DTD/xhtml1-strict.dtd">
<!--
   COLEMAN UNIVERSITY
   COM230 SQL AND DATABASE DESIGN
   Project 4
   Famous Quotes CMS; Managing Authors 

   Author: Michael Fetick, 84270
   Date:   22 September 2013

   Location/Filename: quotelist.php
   Supporting Files: (none)
-->
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<title>Quote CMS: Manage Quotes</title>
<meta http-equiv="content-type"
    content="text/html; charset=iso-8859-1" />
</head>
<body>
<h1>Manage Quotes</h1>
<?php

$dbcnx = @mysql_connect('localhost', 'pm84270', 'c4891a25');
if (!$dbcnx) 
{
  exit('<p>Unable to connect to the ' .
      'database server at this time.</p>');
}

if (!@mysql_select_db('pm84270')) 
{
  exit('<p>Unable to locate the ' .
      'database at this time.</p>');
}

// The basic SELECT statement
$select = 'SELECT DISTINCT fq_quotes.quote_id, quotetext';
$from   = ' FROM fq_quotes';
$where  = ' WHERE 1=1';

$aid = $_POST['aid'];
if ($aid != '') 
{ 
  // An author is selected
  $where .= " AND author_id = '$aid'";
}else{
  // An author is not selected
  $where .= " AND fq_quotes.author_id = author_id";
}

$cid = $_POST['cid'];
if ($cid != '') 
{ 
  // A category is selected
  $from  .= ', fq_quotecategory';
  $where .= " AND fq_quotes.quote_id = fq_quotecategory.quote_id AND category_id='$cid'";
}

$searchtext = $_POST['searchtext'];
if ($searchtext != '') 
{ 
  // Some search text was specified
  $where .= " AND quotetext LIKE '%$searchtext%'";
}
?>

<table>
<tr><th><u>Author of the Quote</u></th><th><u>Quote Text</u></th><th><u>Options</u></th></tr>

<?php

$authors = @mysql_query("SELECT name, email FROM fq_author WHERE fq_author.author_id = fq_author.author_id");
if (!$authors) 
{
  echo '</table>';
  exit('<p>Error retrieving authors from the database!<br />'.
      'Error: ' . mysql_error() . '</p>');
}
// Fetch the quote text
$quotes  = @mysql_query($select . $from . $where);
if (!$quotes) 
{
  echo '</table>';
  exit('<p>Error retrieving quotes from the database!<br />'.
      'Error: ' . mysql_error() . '</p>');
}
while ($quote = mysql_fetch_array($quotes)) 
{
  $author = mysql_fetch_array($authors);
  $authorname  = htmlspecialchars($author['name']);
  $authoremail = htmlspecialchars($author['email']);

  echo "<tr valign='top'>\n";
  $qid = $quote['quote_id'];

  $quotetext = htmlspecialchars($quote['quotetext']);
  echo "<td>$authorname</td>";
  echo "<td>$quotetext</td>\n";
  echo "<td><a href='editquote.php?qid=$qid'>Edit</a> &bullet; " .
      "<a href='deletequote.php?qid=$qid'>Delete</a></td>\n";
  echo "</tr>\n";
}
?>

</table>

<p><a href="quotes.php">New search</a></p>
</body>
</html>
