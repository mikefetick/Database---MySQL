<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Strict//EN"
"http://www.w3.org/TR/xhtml1/DTD/xhtml1-strict.dtd">
<!--
   COLEMAN UNIVERSITY
   COM230 SQL AND DATABASE DESIGN
   Project 4
   Famous Quotes CMS; Managing Authors 

   Author: Michael Fetick, 84270
   Date:   22 September 2013

   Location/Filename: newcat.php
   Supporting Files: (none)
-->
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<title>Quote CMS: Add New Category</title>
</head>
<body>
<?php if (isset($_POST['cname'])):

  // A new category has been entered
  // using the form below.

$dbcnx = @mysql_connect('localhost', 'pm84270', 'c4891a25');
  if (!$dbcnx) 
  {
    exit('<p>Unable to connect to the ' .
        'database server at this time.</p>');
  }
  
if (!@mysql_select_db('pm84270')) 
  {
    exit('<p>Unable to locate the ' .
        'database at this time.</p>');
  }

  $cname = $_POST['cname'];
  $sql = "INSERT INTO fq_category SET name='$cname'";
  
if (@mysql_query($sql)) 
{
    echo '<p>New category added</p>';
} 
else 
{
    echo '<p>Error adding new category: ' .
         mysql_error() . '</p>';
}

?>

<p><a href="<?php echo $_SERVER['PHP_SELF']; ?>">Add another category</a></p>
<p><a href="categories.php">Return to category list</a></p>

<?php else: // Allow the user to enter a new category ?>

<form action="<?php echo $_SERVER['PHP_SELF']; ?>" method="post">
<p>Enter the new category:</p>
<label>Name: <input type="text" name="cname" /></label><br />
<input type="submit" value="SUBMIT" />
</form>

<?php endif; ?>

</body>
</html>
