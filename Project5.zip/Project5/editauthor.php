<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Strict//EN"
"http://www.w3.org/TR/xhtml1/DTD/xhtml1-strict.dtd">
<!--
   COLEMAN UNIVERSITY
   COM230 SQL AND DATABASE DESIGN
   Project 4
   Famous Quotes CMS; Managing Authors 

   Author: Michael Fetick, 84270
   Date:   23 September 2013

   Location/Filename: editauthor.php
   Supporting Files: (none)
-->
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<title>Quote CMS: Edit Author</title>
<meta http-equiv="content-type"
    content="text/html; charset=iso-8859-1" />
</head>
<body>
<h1>Edit Authors</h1>
<?php

$dbcnx = @mysql_connect('localhost', 'pm84270', 'c4891a25');
if (!$dbcnx) 
{
	exit('<p>Unable to connect to the ' .
     'database server at this time.</p>');
}

if (!@mysql_select_db('pm84270')) 
{
	exit('<p>Unable to locate the ' .
		 'database at this time.</p>');
}

if (isset($_POST['aname'])):
// The author's details have been updated.

$aname = $_POST['aname'];
$email = $_POST['email'];
$aid = $_POST['aid'];
$sql = "UPDATE fq_author SET
			name='$aname',
			email='$email'
			WHERE author_id='$aid'";
if (@mysql_query($sql)) {
	echo '<p>Author details updated.</p>';
} else {
	echo '<p>Error updating author details: ' .
	mysql_error() . '</p>';
}

?>

<p><a href="authors.php">Return to authors list</a></p>

<?php
else: // Allow the user to edit the author

	$aid = $_GET['aid'];
	$author = @mysql_query(
		"SELECT name, email FROM fq_author WHERE author_id='$aid'");
	if (!$author) {
		exit('<p>Error fetching author details: ' .
		mysql_error() . '</p>');
	}

	$author = mysql_fetch_array($author);

	$aname = $author['name'];
	$email = $author['email'];
// Convert special characters for safe use
// as HTML attributes.
$aname = htmlspecialchars($aname);
$email = htmlspecialchars($email);

?>

<form action="<?php echo $_SERVER['PHP_SELF']; ?>" method="post">
<p>Edit the author:</p>
<label>Name: <input type="text" name="aname" value="<?php echo $aname; ?>" /></label><br />
<label>Email: <input type="text" name="email" value="<?php echo $email; ?>" /></label><br />
<input type="hidden" name="aid" value="<?php echo $aid; ?>" />
<input type="submit" value="SUBMIT" />
</form>

<?php endif; ?>

</body>
</html>
