<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Strict//EN"
"http://www.w3.org/TR/xhtml1/DTD/xhtml1-strict.dtd">
<!--
   COLEMAN UNIVERSITY
   COM230 SQL AND DATABASE DESIGN
   Project 4
   Famous Quotes CMS; Managing Authors 

   Author: Michael Fetick, 84270
   Date:   22 September 2013

   Location/Filename: quotelist.php
   Supporting Files: (none)
-->
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<title>Quote CMS: Manage Quotes</title>
<meta http-equiv="content-type"
    content="text/html; charset=iso-8859-1" />
</head>
<body>
<h1>Manage Quotes</h1>
<?php

$dbcnx = @mysql_connect('localhost', 'pm84270', 'c4891a25');
if (!$dbcnx) 
{
  exit('<p>Unable to connect to the ' .
      'database server at this time.</p>');
}

if (!@mysql_select_db('pm84270')) 
{
  exit('<p>Unable to locate the ' .
      'database at this time.</p>');
}

// The basic SELECT statement
$select = 'SELECT DISTINCT fq_quotes.quote_id, quotetext';
$from   = ' FROM fq_quotes';
$where  = ' WHERE 1=1';

$aid = $_POST['aid'];
if ($aid != '') 
{ 
  // An author is selected
  $where .= " AND author_id = '$aid'";
  
  $authorofquote = @mysql_query("SELECT name FROM fq_author WHERE author_id = 1");
}

$cid = $_POST['cid'];
if ($cid != '') 
{ 
  // A category is selected
  $from  .= ', fq_quotecategory';
  $where .= " AND fq_quotes.quote_id = fq_quotecategory.quote_id AND category_id='$cid'";
}

$searchtext = $_POST['searchtext'];
if ($searchtext != '') 
{ 
  // Some search text was specified
  $where .= " AND quotetext LIKE '%$searchtext%'";
}
?>

<table>
<tr><th>Author of the Quote</th><th>Quote Text</th><th>Options</th></tr>

<?php
$quotes = @mysql_query($select . $from . $where);

if (!$quotes) 
{
  echo '</table>';
  exit('<p>Error retrieving quotes from database!<br />'.
      'Error: ' . mysql_error() . '</p>');
}

//  $authorofquote = @mysql_query("SELECT name FROM fq_author WHERE author_id='$aid'");

while ($quote = mysql_fetch_array($quotes)) 
{
  echo "<tr valign='top'>\n";
  $qid = $quote['quote_id'];

//  $quotedauthor = @mysql_query("SELECT name FROM fq_author WHERE author_id = '$aid'");
//  $authorofquote = $quotedauthor;
//  $authorofquote = $aid;
//  echo "<td>$aid</td>\n";

  $quotetext = htmlspecialchars($quote['quotetext']);
  echo "<td>$authorofquote</td>\n";

  echo "<td>$quotetext</td>\n";
  echo "<td><a href='editquote.php?qid=$qid'>Edit</a> | " .
      "<a href='deletequote.php?qid=$qid'>Delete</a></td>\n";
  echo "</tr>\n";
}
?>

</table>

<p><a href="quotes.php">New search</a></p>
</body>
</html>
